document.addEventListener("DOMContentLoaded", function () {
    const convertButton = document.getElementById("convertButton");

    convertButton.addEventListener("click", function () {
        const temperatureInput = parseFloat(document.getElementById("temperatureInput").value);
        const unitInput = document.getElementById("unitInput").value;
        let result = "";

        if (isNaN(temperatureInput)) {
            result = "Please enter a valid temperature.";
        } else {
            if (unitInput === "celsius") {
                const fahrenheit = (temperatureInput * 9/5) + 32;
                result = `${temperatureInput} Celsius is equal to ${fahrenheit.toFixed(2)} Fahrenheit.`;
            } else {
                const celsius = (temperatureInput - 32) * 5/9;
                result = `${temperatureInput} Fahrenheit is equal to ${celsius.toFixed(2)} Celsius.`;
            }
        }

        document.getElementById("result").textContent = result;
    });
});
